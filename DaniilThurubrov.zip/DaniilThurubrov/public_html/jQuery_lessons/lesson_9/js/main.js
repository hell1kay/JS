$(function() {
	$('p').text('DOM элементы загружены')
});

$(window).load(function() {
});

$(window).load(function() {
	alert('Пользователь, пока!')
});

$(window).load(function() {
	console.log('размеры окна изменены!')
});

$(window).load(function() {
	console.log('Страница прокручена')
});