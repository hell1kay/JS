/* ====== Фильтры ====== */

/* Простые фильтры в jQuery */

 $('li:contains(файл)').css('border', 'solid 1px red'); // содержит текст
// $('p:empty').text('Любой текст') // пустой
// $('h2:has(span)').css('border', '1px solid #000'); // имеет внутри селектор
// $('span:parent').css('border', '1px solid #000'); // обращение к родителб