$('h2, p')
$('h2 span')
$('h2 > span')
$('h2 + p')
$('h2 ~ p').css('border', '2px soild #000');
