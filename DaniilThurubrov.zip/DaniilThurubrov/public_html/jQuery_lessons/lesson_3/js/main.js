$('a[download]').css('border', '1px solid red');
$('a[href="http://ya.ru"]').css('border', '1px solid red');
$('a[href!="http://ya.ru"]').css('border', '1px solid red');
$('a[href^="http"]').css('border', '1px solid red');
$('a[href$=".com"]').css('border', '1px solid red');
$('a[href*="google"]').css('border', '1px solid red');
$('a[data-target|="main"]').css('border', '1px solid red');
$('a[href][download]').css('border', '1px solid red');